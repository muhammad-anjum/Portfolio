# Muhammad Anjum — Technical Portfolio (Interactive)

Interactive single‑page portfolio (no build step). Update data in `/data/*.json` and assets in `/assets`. Deployed via GitHub Pages Actions.
